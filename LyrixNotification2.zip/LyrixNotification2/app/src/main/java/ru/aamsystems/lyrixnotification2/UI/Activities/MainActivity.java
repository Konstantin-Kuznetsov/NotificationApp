package ru.aamsystems.lyrixnotification2.UI.Activities;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;
import ru.aamsystems.lyrixnotification2.R;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private NavController navController; // контроллер навигации по фрагментам
    DrawerLayout drawer; // Выдвижное навигационное меню

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Установить Toolbar для замены ActionBar'а.
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        // инициализация контроллера навигации по фрагментам
        navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        // привязка навигационного контроллера к выдвижному меню, с синхронизацией 
        NavigationUI.setupActionBarWithNavController(this, navController, drawer);
    }


}
